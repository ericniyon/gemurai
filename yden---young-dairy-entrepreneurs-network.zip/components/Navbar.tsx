import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Milk, User } from 'lucide-react';
import Button from './ui/Button';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'About', href: '/about' },
    { label: 'Programs', href: '/programs' },
    { label: 'For Youth', href: '/youth' },
    { label: 'For Partners', href: '/partners' },
    { label: 'Resources', href: '/resources' },
    { label: 'News', href: '/news' },
    { label: 'Contact', href: '/contact' },
  ];

  // Determine if the navbar should have a solid background (scrolled, not home, or menu open)
  const isSolid = scrolled || isOpen || location.pathname !== '/';

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isSolid ? 'bg-white/95 backdrop-blur-md shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="bg-yden-blue p-2 rounded-lg group-hover:bg-blue-800 transition-colors">
                <Milk className="h-8 w-8 text-white" />
              </div>
              <div className="flex flex-col">
                <span className={`font-bold text-2xl leading-none tracking-tight ${isSolid ? 'text-yden-blue' : 'text-yden-blue md:text-white'}`}>
                  YDEN
                </span>
                <span className={`text-[10px] font-medium tracking-wider uppercase ${isSolid ? 'text-slate-500' : 'text-slate-300 md:text-blue-100'}`}>
                  Young Dairy Entrepreneurs
                </span>
              </div>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-1 lg:space-x-4">
            {navLinks.map((link) => {
              const isActive = location.pathname === link.href;
              const isHome = location.pathname === '/';
              
              // Desktop text color logic
              const textColor = scrolled || !isHome ? 'text-slate-600 hover:text-yden-blue' : 'text-blue-100 hover:text-white';
              const activeColor = scrolled || !isHome ? 'text-yden-blue font-semibold' : 'text-white font-semibold';

              return (
                <Link
                  key={link.href}
                  to={link.href}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive ? activeColor : textColor}`}
                >
                  {link.label}
                </Link>
              );
            })}
            <Link to="/portal" className="ml-2">
                <div className={`p-2 rounded-full transition-colors ${scrolled || location.pathname !== '/' ? 'bg-slate-100 text-yden-blue hover:bg-slate-200' : 'bg-white/20 text-white hover:bg-white/30'}`}>
                    <User className="w-5 h-5" />
                </div>
            </Link>
            <div className="pl-2">
                <Button to="/youth" variant={scrolled || location.pathname !== '/' ? 'primary' : 'secondary'} className="py-2 px-4 text-sm">
                Join YDEN
                </Button>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`inline-flex items-center justify-center p-2 rounded-md transition-colors ${
                isSolid ? 'text-slate-600 hover:bg-slate-100' : 'text-white hover:bg-white/10'
              } focus:outline-none focus:ring-2 focus:ring-inset focus:ring-yden-blue`}
              aria-expanded={isOpen}
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu with Transition */}
      <div 
        className={`md:hidden absolute top-full left-0 w-full bg-white shadow-xl border-t border-slate-100 overflow-hidden transition-all duration-300 ease-in-out origin-top ${
          isOpen ? 'max-h-[85vh] opacity-100 visible' : 'max-h-0 opacity-0 invisible'
        }`}
      >
        <div className="px-4 py-6 space-y-3 overflow-y-auto max-h-[80vh]">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`block px-4 py-3 rounded-lg text-base font-medium transition-colors ${
                  location.pathname === link.href
                    ? 'text-yden-blue bg-blue-50 border-l-4 border-yden-blue'
                    : 'text-slate-600 hover:text-yden-blue hover:bg-slate-50'
                }`}
              >
                {link.label}
              </Link>
            ))}
            
            <div className="border-t border-slate-100 my-4 pt-4 space-y-4">
                <Link 
                    to="/portal"
                    className="flex items-center px-4 py-3 text-base font-medium text-slate-600 hover:text-yden-blue hover:bg-slate-50 rounded-lg"
                >
                    <User className="w-5 h-5 mr-3" />
                    Member Portal Login
                </Link>
                
                <div className="px-4">
                    <Button to="/youth" variant="primary" className="w-full justify-center py-3">
                        Join YDEN
                    </Button>
                </div>
            </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;