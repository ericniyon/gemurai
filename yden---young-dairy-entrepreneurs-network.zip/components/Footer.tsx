import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, MapPin, Phone, Mail, Milk } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="bg-white/10 p-2 rounded-lg">
                <Milk className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-white">YDEN</span>
            </div>
            <p className="text-sm leading-relaxed text-slate-400">
              The home of youth in the dairy value chain in Rwanda. Building a new generation of skilled, profitable, and climate-smart dairy entrepreneurs.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-white transition-colors"><Twitter className="h-5 w-5" /></a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors"><Linkedin className="h-5 w-5" /></a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors"><Instagram className="h-5 w-5" /></a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors"><Facebook className="h-5 w-5" /></a>
            </div>
          </div>

          {/* Column 1 */}
          <div>
            <h3 className="text-white text-sm font-bold uppercase tracking-wider mb-4">YDEN</h3>
            <ul className="space-y-3">
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/programs" className="hover:text-white transition-colors">Programs</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">Our Model</Link></li>
              <li><Link to="/news" className="hover:text-white transition-colors">News & Events</Link></li>
            </ul>
          </div>

          {/* Column 2 */}
          <div>
            <h3 className="text-white text-sm font-bold uppercase tracking-wider mb-4">Get Involved</h3>
            <ul className="space-y-3">
              <li><Link to="/youth" className="hover:text-white transition-colors">Join as Youth</Link></li>
              <li><Link to="/partners" className="hover:text-white transition-colors">Become a Partner</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Volunteer / Mentor</Link></li>
              <li><Link to="/resources" className="hover:text-white transition-colors">Resources & Toolkits</Link></li>
            </ul>
          </div>

          {/* Contact Column */}
          <div>
            <h3 className="text-white text-sm font-bold uppercase tracking-wider mb-4">Contact</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Mail className="h-5 w-5 text-yden-green mr-3 mt-0.5" />
                <span>info@yden.rw</span>
              </li>
              <li className="flex items-start">
                <Phone className="h-5 w-5 text-yden-green mr-3 mt-0.5" />
                <span>+250 788 123 456</span>
              </li>
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-yden-green mr-3 mt-0.5" />
                <span>Kigali, Rwanda</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-slate-500">
            &copy; {new Date().getFullYear()} Young Dairy Entrepreneurs Network (YDEN). All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0 text-sm text-slate-500">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Use</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;