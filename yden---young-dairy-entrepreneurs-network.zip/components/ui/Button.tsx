import React from 'react';
import { Link } from 'react-router-dom';

interface ButtonProps {
  children: React.ReactNode;
  to?: string;
  variant?: 'primary' | 'secondary' | 'outline' | 'white';
  className?: string;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  to, 
  variant = 'primary', 
  className = '', 
  onClick,
  type = 'button'
}) => {
  const baseStyles = "inline-flex items-center justify-center px-6 py-3 border text-base font-medium rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    primary: "border-transparent text-white bg-yden-blue hover:bg-blue-900 hover:shadow-xl focus:ring-yden-blue shadow-lg shadow-blue-900/20",
    secondary: "border-transparent text-white bg-yden-green hover:bg-green-700 hover:shadow-xl focus:ring-green-500 shadow-lg shadow-green-600/20",
    outline: "border-yden-blue text-yden-blue bg-transparent hover:bg-blue-50 focus:ring-yden-blue",
    white: "border-transparent text-yden-blue bg-white hover:bg-gray-50 focus:ring-white shadow-lg hover:shadow-xl"
  };

  const combinedClassName = `${baseStyles} ${variants[variant]} ${className}`;

  if (to) {
    return (
      <Link to={to} className={combinedClassName}>
        {children}
      </Link>
    );
  }

  return (
    <button type={type} onClick={onClick} className={combinedClassName}>
      {children}
    </button>
  );
};

export default Button;