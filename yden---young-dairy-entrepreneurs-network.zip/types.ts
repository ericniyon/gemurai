import { ReactNode } from 'react';

export interface NavItem {
  label: string;
  href: string;
  isButton?: boolean;
}

export interface Program {
  id: string;
  title: string;
  description: string;
  audience: string;
  icon?: ReactNode;
}

export interface Partner {
  name: string;
  role: string;
  description: string;
}

export interface Resource {
  id: string;
  title: string;
  type: 'toolkit' | 'guide' | 'story' | 'download';
  description: string;
  link: string;
}

export interface NewsItem {
  id: string;
  title: string;
  date: string;
  category: string;
  summary: string;
}