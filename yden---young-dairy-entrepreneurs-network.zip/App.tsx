import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Programs from './pages/Programs';
import Youth from './pages/Youth';
import Partners from './pages/Partners';
import Resources from './pages/Resources';
import News from './pages/News';
import Contact from './pages/Contact';
import Portal from './pages/Portal';

// Wrapper to conditionally hide layout elements on specific pages
const LayoutWrapper: React.FC<{children: React.ReactNode}> = ({ children }) => {
    const location = useLocation();
    const isPortal = location.pathname === '/portal';

    return (
        <div className="flex flex-col min-h-screen font-sans text-slate-900">
            {!isPortal && <Navbar />}
            <main className="flex-grow">
                {children}
            </main>
            {!isPortal && <Footer />}
        </div>
    );
};

// Enhanced Scroll Handler
const ScrollToTop = () => {
    const { pathname, hash } = useLocation();

    React.useEffect(() => {
        // If a hash is present (e.g. #how-it-works), scroll to that element smoothly
        if (hash) {
            const scrollToElement = () => {
                const element = document.getElementById(hash.replace('#', ''));
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    return true;
                }
                return false;
            };

            // Attempt immediately
            if (!scrollToElement()) {
                // Retry briefly for dynamic content/loading delays
                const timer = setTimeout(scrollToElement, 100);
                return () => clearTimeout(timer);
            }
        } 
        // Otherwise, standard scroll to top for new pages
        else {
            // Use 'auto' behavior to ensure instant scroll-to-top on page change, 
            // overriding the global CSS scroll-behavior: smooth which can be jarring for page loads.
            window.scrollTo({ top: 0, behavior: 'auto' });
        }
    }, [pathname, hash]);

    return null;
}

const App: React.FC = () => {
  return (
    <Router>
      <LayoutWrapper>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/programs" element={<Programs />} />
          <Route path="/youth" element={<Youth />} />
          <Route path="/partners" element={<Partners />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/news" element={<News />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/portal" element={<Portal />} />
        </Routes>
      </LayoutWrapper>
    </Router>
  );
};

export default App;