import React from 'react';
import { CheckCircle, UserPlus, ArrowRight } from 'lucide-react';
import Button from '../components/ui/Button';
import ScrollReveal from '../components/ui/ScrollReveal';

const Youth: React.FC = () => {
  return (
    <div className="pt-16 min-h-screen bg-white">
      {/* Hero */}
      <div className="bg-slate-900 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-30">
            <img src="https://images.unsplash.com/photo-1488459716781-31db52582fe9?q=80&w=2000&auto=format&fit=crop" alt="Youth in Field" className="w-full h-full object-cover" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-12 items-center relative z-10">
          <div className="animate-fade-in-up">
            <span className="text-green-400 font-bold uppercase tracking-wider text-sm mb-2 block">For Aspiring Agripreneurs</span>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">Are you ready to build your <span className="text-blue-400">dairy business</span>?</h1>
            <p className="text-xl text-slate-200 mb-8">
              YDEN helps you start and grow as a young dairy entrepreneur – even if you don’t own cows yet. We provide the skills, the tech, and the market.
            </p>
            <Button variant="secondary" onClick={() => document.getElementById('apply')?.scrollIntoView({behavior: 'smooth'})}>
              Start Your Application
            </Button>
          </div>
          <div className="hidden md:block rounded-2xl overflow-hidden shadow-2xl border-4 border-slate-700 transform rotate-2 hover:rotate-0 transition-transform duration-500 animate-fade-in-up delay-200">
             <img src="https://images.unsplash.com/photo-1605000797499-95a51c5269ae?q=80&w=1000&auto=format&fit=crop" alt="Farming Logistics" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      {/* Content Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-2 gap-16">
          {/* Requirements */}
          <ScrollReveal>
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Who can join?</h2>
            <ul className="space-y-4">
              {[
                "Age 18–35",
                "Living in Rwanda (Rural or Peri-urban)",
                "Interested in dairy production, milk aggregation, or cold chain logistics",
                "Willing to commit time and effort to training and implementation"
              ].map((req, i) => (
                <li key={i} className="flex items-center text-slate-700 bg-slate-50 p-4 rounded-lg border border-slate-100">
                  <CheckCircle className="w-5 h-5 text-yden-green mr-3 flex-shrink-0" />
                  {req}
                </li>
              ))}
            </ul>
          </ScrollReveal>

          {/* Benefits */}
          <ScrollReveal delay={200}>
            <h2 className="text-2xl font-bold text-slate-900 mb-6">What you get</h2>
            <div className="space-y-6">
                <div className="flex">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-yden-blue font-bold">1</div>
                    <div className="ml-4">
                        <h3 className="text-lg font-medium text-slate-900">Training & Coaching</h3>
                        <p className="mt-1 text-slate-600">Technical skills in husbandry and milk handling + business basics.</p>
                    </div>
                </div>
                <div className="flex">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-yden-blue font-bold">2</div>
                    <div className="ml-4">
                        <h3 className="text-lg font-medium text-slate-900">Practical Opportunities</h3>
                        <p className="mt-1 text-slate-600">Matched with calves, aggregation routes, or feed contracts.</p>
                    </div>
                </div>
                <div className="flex">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-yden-blue font-bold">3</div>
                    <div className="ml-4">
                        <h3 className="text-lg font-medium text-slate-900">Market Linkages</h3>
                        <p className="mt-1 text-slate-600">Direct connection to buyers like Gemura and other processors.</p>
                    </div>
                </div>
            </div>
          </ScrollReveal>
        </div>
      </div>

      {/* How to Apply */}
      <div id="apply" className="bg-slate-50 py-20 border-t border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <h2 className="text-3xl font-bold text-slate-900 mb-12">How to Apply</h2>
            <div className="grid md:grid-cols-4 gap-6 text-left">
              {[
                "Fill in the online application form.",
                "Shortlisting & interviews for each cohort.",
                "Successful applicants join a bootcamp.",
                "Match with real opportunities."
              ].map((step, i) => (
                <div key={i} className="relative bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                  <span className="absolute top-4 right-4 text-4xl font-bold text-slate-100 -z-10">{i + 1}</span>
                  <p className="font-medium text-slate-800">{step}</p>
                </div>
              ))}
            </div>
          </ScrollReveal>
          
          <ScrollReveal delay={200} className="mt-12 space-y-4">
            <Button className="text-lg px-12 py-4 shadow-xl transform hover:-translate-y-1 transition-all">
                Apply to Join YDEN
            </Button>
            <p className="text-sm text-slate-500">
                If you have limited internet access, contact us through your local partner hub or cooperative.
            </p>
          </ScrollReveal>
        </div>
      </div>
    </div>
  );
};

export default Youth;