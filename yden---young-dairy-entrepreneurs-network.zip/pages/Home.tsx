import React, { useEffect, useRef, useState } from 'react';
import { ArrowRight, TrendingUp, Users, Award, Briefcase, Sprout, Truck, Thermometer, Droplets, ChevronRight, Play } from 'lucide-react';
import Button from '../components/ui/Button';
import ScrollReveal from '../components/ui/ScrollReveal';

const Home: React.FC = () => {
  const parallaxRef = useRef<HTMLDivElement>(null);
  const [videoLoaded, setVideoLoaded] = useState(false);

  useEffect(() => {
    let rafId: number;

    const handleScroll = () => {
      // Use requestAnimationFrame for smoother visual updates
      cancelAnimationFrame(rafId);
      
      rafId = requestAnimationFrame(() => {
        if (parallaxRef.current) {
          const scrolled = window.scrollY;
          // Parallax effect: move the container down at 40% of scroll speed.
          // We no longer scale here; CSS handles the gentle zoom.
          parallaxRef.current.style.transform = `translateY(${scrolled * 0.4}px)`;
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <div className="flex flex-col w-full overflow-hidden bg-white">
      {/* Hero Section - Immersive with Video/Image Background */}
      <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
        {/* Background Video Container - Handles Parallax Translation */}
        <div ref={parallaxRef} className="absolute inset-0 z-0 bg-slate-900 will-change-transform">
          {/* Animation Wrapper - Handles Zoom for both Image and Video */}
          <div className="relative w-full h-full animate-slow-zoom">
            {/* Fallback Image - Always visible immediately */}
            <img 
              src="https://images.unsplash.com/photo-1500595046743-cd271d694d30?q=80&w=2074&auto=format&fit=crop" 
              alt="Hero Background" 
              className="absolute inset-0 w-full h-full object-cover"
            />
            
            {/* Video Overlay - Fades in when ready */}
            <video
              autoPlay
              muted
              loop
              playsInline
              onCanPlay={() => setVideoLoaded(true)}
              className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ease-in-out ${videoLoaded ? 'opacity-100' : 'opacity-0'}`}
            >
              {/* Stock video of cows grazing in green pasture - representing Rwanda's hills */}
              <source src="https://videos.pexels.com/video-files/855072/855072-hd_1920_1080_25fps.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
          
          {/* Dark Overlay with Blue Tint */}
          <div className="absolute inset-0 bg-slate-900/60 mix-blend-multiply"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white mb-8 animate-fade-in-up">
             <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
             <span className="text-sm font-medium tracking-wide uppercase">The Future of Rwandan Dairy</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold text-white tracking-tight leading-tight mb-6 animate-fade-in-up delay-100 drop-shadow-lg">
            From <span className="text-green-400">Farm</span> to <span className="text-blue-400">Market</span>.<br/>
            Powered by Youth.
          </h1>
          
          <p className="text-xl md:text-2xl text-slate-200 max-w-3xl mx-auto mb-10 font-light leading-relaxed animate-fade-in-up delay-200">
            YDEN connects Milk Collection Centers, Farmers, and Processors through a network of skilled young entrepreneurs. We professionalize the value chain.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up delay-300">
            <Button to="/youth" variant="secondary" className="text-lg px-8 py-4 shadow-green-900/20 shadow-xl hover:shadow-2xl transform hover:-translate-y-1">
              Join the Network
            </Button>
            <Button to="/partners" variant="white" className="text-lg px-8 py-4 shadow-xl hover:shadow-2xl transform hover:-translate-y-1">
              Partner with Us
            </Button>
          </div>
        </div>

        {/* Bottom Ticker / Stats */}
        <div className="absolute bottom-0 w-full border-t border-white/10 bg-slate-900/50 backdrop-blur-md py-4 z-20 hidden md:block animate-fade-in delay-500">
           <div className="max-w-7xl mx-auto px-6 flex justify-between text-sm text-slate-300">
              <div className="flex gap-8">
                 <span className="flex items-center gap-2"><TrendingUp className="text-green-400 w-4 h-4" /> Milk Production +15% YoY</span>
                 <span className="flex items-center gap-2"><Users className="text-blue-400 w-4 h-4" /> 120+ Youth Deployed</span>
                 <span className="flex items-center gap-2"><Truck className="text-yden-blue w-4 h-4" /> 5 Districts Covered</span>
              </div>
              <div className="font-mono text-slate-400">
                 Partnering with <span className="text-white font-bold">GEMURA</span> & <span className="text-white font-bold">KIVU COLD</span>
              </div>
           </div>
        </div>
      </section>

      {/* The Dairy Ecosystem Section */}
      <section id="who-we-are" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
             {/* Left: Text */}
             <ScrollReveal>
                <h4 className="text-yden-blue font-bold uppercase tracking-widest text-sm mb-2">Who We Are</h4>
                <h2 className="text-4xl font-bold text-slate-900 mb-6 leading-tight">
                   Modernizing the <span className="text-yden-blue">White Gold</span> Economy
                </h2>
                <p className="text-slate-600 text-lg mb-6 leading-relaxed">
                   Rwanda's dairy sector is growing, but gaps in skills, cold chain logistics, and data management remain. 
                   <strong className="text-slate-900"> YDEN (Young Dairy Entrepreneurs Network)</strong> bridges this gap.
                </p>
                <p className="text-slate-600 text-lg mb-8 leading-relaxed">
                   We select and train youth to operate as professional service providers—managing youngstock, running Milk Collection Centers (MCC) operations, and ensuring quality from udder to processing plant.
                </p>
                
                <ul className="space-y-4 mb-8">
                   {[
                      "Professionalizing Milk Collection Centers (MCCs)",
                      "Reducing post-harvest losses via Cold Chain",
                      "Improving fodder & feeding systems"
                   ].map((item, i) => (
                      <li key={i} className="flex items-center text-slate-700 font-medium">
                         <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-3">
                            <ArrowRight size={14} />
                         </div>
                         {item}
                      </li>
                   ))}
                </ul>

                <a href="/about" className="text-yden-blue font-bold flex items-center gap-2 hover:gap-3 transition-all group">
                   Learn about our model <ChevronRight size={20} />
                </a>
             </ScrollReveal>

             {/* Right: Image Grid */}
             <ScrollReveal delay={200} className="hidden lg:block relative h-[600px]">
                {/* Main Image: Milk Collection */}
                <div className="absolute top-0 right-0 w-4/5 h-3/5 rounded-2xl overflow-hidden shadow-2xl z-10">
                   <img src="https://images.unsplash.com/photo-1527153818091-1a9638521e2a?q=80&w=1000&auto=format&fit=crop" alt="Milk Processing" className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" />
                   <div className="absolute bottom-0 left-0 bg-yden-blue text-white px-6 py-3 font-bold">
                      Milk Aggregation
                   </div>
                </div>
                {/* Secondary Image: Farmer */}
                <div className="absolute bottom-0 left-0 w-3/5 h-1/2 rounded-2xl overflow-hidden shadow-2xl z-20 border-4 border-white">
                   <img src="https://images.unsplash.com/photo-1595414688142-d92053d35963?q=80&w=800&auto=format&fit=crop" alt="Young Farmer" className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" />
                </div>
                {/* Floating Badge */}
                <div className="absolute top-1/2 left-10 bg-white p-4 rounded-lg shadow-xl z-30 flex items-center gap-3 animate-float">
                   <div className="bg-blue-50 p-3 rounded-full text-yden-blue">
                      <Droplets size={24} />
                   </div>
                   <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Daily Collection</p>
                      <p className="text-xl font-bold text-slate-900">50,000 L+</p>
                   </div>
                </div>
             </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Core Value Chain Services */}
      <section id="services" className="py-24 bg-white">
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal className="text-center mb-16">
               <span className="text-green-600 font-bold tracking-wide uppercase text-sm">Value Chain Focus</span>
               <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mt-2">Supporting Every Drop</h2>
            </ScrollReveal>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
               {[
                  {
                     icon: <Sprout size={32} />,
                     title: "Production & Fodder",
                     desc: "Expert youngstock management, breed improvement, and year-round fodder production.",
                     color: "text-green-600",
                     bg: "bg-green-50",
                     img: "https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=400&q=80"
                  },
                  {
                     icon: <Droplets size={32} />,
                     title: "Milk Hygiene",
                     desc: "Testing services and clean handling protocols to minimize rejection rates at MCCs.",
                     color: "text-blue-500",
                     bg: "bg-blue-50",
                     img: "https://images.unsplash.com/photo-1559736463-56f3448c809a?auto=format&fit=crop&w=400&q=80"
                  },
                  {
                     icon: <Thermometer size={32} />,
                     title: "Cold Chain",
                     desc: "Managing chilling infrastructure and refrigerated logistics to preserve quality.",
                     color: "text-cyan-500",
                     bg: "bg-cyan-50",
                     img: "https://images.unsplash.com/photo-1635361653830-114df8294a30?auto=format&fit=crop&w=400&q=80"
                  },
                  {
                     icon: <Truck size={32} />,
                     title: "Logistics & Market",
                     desc: "Efficient aggregation and transport connecting farmers to major processors.",
                     color: "text-indigo-600",
                     bg: "bg-indigo-50",
                     img: "https://images.unsplash.com/photo-1605000797499-95a51c5269ae?auto=format&fit=crop&w=400&q=80"
                  }
               ].map((card, i) => (
                  <ScrollReveal key={i} delay={i * 100}>
                    <div className="group relative rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 h-80">
                       {/* Background Image */}
                       <div className="absolute inset-0">
                          <img src={card.img} alt={card.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/80 to-slate-900/30 group-hover:via-slate-900/60 transition-colors"></div>
                       </div>
                       
                       {/* Content */}
                       <div className="absolute inset-0 p-8 flex flex-col justify-end items-start">
                          <div className={`mb-4 p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 text-white`}>
                             {card.icon}
                          </div>
                          <h3 className="text-xl font-bold text-white mb-2">{card.title}</h3>
                          <p className="text-slate-300 text-sm leading-relaxed opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                             {card.desc}
                          </p>
                       </div>
                    </div>
                  </ScrollReveal>
               ))}
            </div>
         </div>
      </section>

      {/* Impact Statistics with Parallax */}
      <section id="impact" className="py-20 bg-yden-blue relative overflow-hidden bg-fixed" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1632663287425-56454b677885?q=80&w=2000&auto=format&fit=crop')" }}>
        <div className="absolute inset-0 bg-yden-blue/90"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <ScrollReveal className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-blue-400/30">
              {[
                  { number: "5", label: "Pilot Districts" },
                  { number: "120+", label: "Youth Trained" },
                  { number: "3", label: "Key Partners" },
                  { number: "20+", label: "Ventures Launched" }
              ].map((stat, i) => (
                  <div key={i} className="p-4">
                      <div className="text-4xl md:text-6xl font-bold text-white mb-2">{stat.number}</div>
                      <div className="text-blue-200 font-medium uppercase tracking-wider text-sm">{stat.label}</div>
                  </div>
              ))}
           </ScrollReveal>
        </div>
      </section>

      {/* How It Works - Timeline */}
      <section id="how-it-works" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900">The YDEN Pathway</h2>
            <p className="text-slate-600 mt-4">How we transform unemployed youth into value chain assets.</p>
          </ScrollReveal>
          
          <div className="relative">
             {/* Connector Line */}
             <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 -translate-y-1/2 z-0"></div>

             <div className="grid md:grid-cols-3 gap-8 relative z-10">
                {[
                   { step: "01", title: "Selection & Training", desc: "Youth recruited from MCC catchment areas and trained in technical dairy skills." },
                   { step: "02", title: "Assets & Deployment", desc: "Equipped with tools (testing kits, bikes, cans) and linked to an MCC." },
                   { step: "03", title: "Market Integration", desc: "Youth provide paid services to farmers or aggregate milk for processors." }
                ].map((item, i) => (
                   <ScrollReveal key={i} delay={i * 200}>
                     <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-100 text-center group hover:-translate-y-2 transition-transform duration-300">
                        <div className="w-16 h-16 mx-auto bg-yden-blue text-white rounded-full flex items-center justify-center text-xl font-bold mb-6 ring-8 ring-blue-50 group-hover:ring-blue-100 transition-all">
                           {item.step}
                        </div>
                        <h3 className="text-xl font-bold text-slate-900 mb-3">{item.title}</h3>
                        <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
                     </div>
                   </ScrollReveal>
                ))}
             </div>
          </div>
        </div>
      </section>

      {/* Featured Farmer Story */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <ScrollReveal className="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
              <div className="md:w-1/2 relative min-h-[400px]">
                 <img 
                    src="https://images.unsplash.com/photo-1528498033381-246f1f202572?q=80&w=1000&auto=format&fit=crop" 
                    alt="Aline at Milk Collection Center" 
                    className="absolute inset-0 w-full h-full object-cover" 
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent"></div>
                 <div className="absolute bottom-8 left-8">
                    <div className="flex items-center gap-2 text-green-400 font-bold mb-2">
                       <Award size={20} /> YDEN Star Entrepreneur
                    </div>
                    <h3 className="text-white text-2xl font-bold">Aline, 24</h3>
                    <p className="text-slate-300">Kayonza District • Milk Aggregator</p>
                 </div>
              </div>
              <div className="md:w-1/2 p-12 md:p-16 flex flex-col justify-center">
                 <h2 className="text-3xl font-bold text-white mb-6">"I don't just sell milk. I manage quality."</h2>
                 <p className="text-slate-300 text-lg leading-relaxed mb-8">
                    "Before YDEN, I was struggling to find work. Now, I manage a collection route for 30 farmers. I use the lactometer to test every liter, ensuring only the best milk goes to Gemura. My income supports my siblings."
                 </p>
                 <Button variant="secondary" className="self-start flex items-center gap-2">
                    <Play size={16} fill="currentColor" /> Watch Her Story
                 </Button>
              </div>
           </ScrollReveal>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-br from-green-600 to-teal-700 py-20 text-center text-white">
         <div className="max-w-4xl mx-auto px-4">
            <ScrollReveal>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to transform the dairy value chain?</h2>
              <p className="text-xl text-green-50 mb-10">
                 Whether you are a young person looking for opportunity, or a processor looking for quality supply.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                 <Button variant="white" to="/youth" className="text-green-700 font-bold px-8 py-4">
                    Apply as Youth
                 </Button>
                 <Button variant="outline" to="/partners" className="border-white text-white hover:bg-white/10 px-8 py-4">
                    Partner with Us
                 </Button>
              </div>
            </ScrollReveal>
         </div>
      </section>
    </div>
  );
};

export default Home;